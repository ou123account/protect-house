import pygame
from pygame.locals import *
import sys
import math
import random

WIDTH = 640
HEIGHT = 480
DEGREE = 180/math.pi

pygame.init()

file_bg_img = "./img/bg.png"
file_castle_img = "./img/castle.png"
file_rabbit_img = "./img/dude.png"
file_arrow_img = "./img/bullet.png"
file_badger_img = "./img/badguy1.png"
file_healthbar_img = "./img/healthbar.png"
file_health_img = "./img/health.png"
file_win_img = "./img/win.png"
file_lose_img = "./img/lose.png"
file_bg_snd = "./snd/moonlight.wav"

file_badger_imgs = []
for i in range(1, 5):
    file_badger_imgs.append("./img/badguy%d.png" % i)


class MainWindow:
    def __init__(self):
        """游戏初始化工作"""
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption("守护家园V4")

        self.bg = pygame.image.load(file_bg_img)
        self.castle = pygame.image.load(file_castle_img)
        self.arrow_image = pygame.image.load(file_arrow_img)

        self.rabbit = Rabbit()
        # 箭头精灵组
        self.arrow_group = pygame.sprite.Group()

        # 平头哥
        self.badger_image = pygame.image.load(file_badger_img)
        # 加载四张图片
        self.badger_images = []
        for tmp in file_badger_imgs:
            self.badger_images.append(pygame.image.load(tmp))
        # 平头哥精灵组
        self.badger_group = pygame.sprite.Group()
        # self.badger = Badger(self.badger_image, (WIDTH//2,HEIGHT//2))
        # 得分变量
        self.score = 0
        # 城堡生命值变量
        self.health_value = 400
        # 倒计时
        self.time_left = 30
        self.time_left_event = USEREVENT + 1

        # 城堡生命值图片
        self.healthbar_image = pygame.image.load(file_healthbar_img)
        self.health_image = pygame.image.load(file_health_img)

        # 结束
        self.win = pygame.image.load(file_win_img)
        self.lose = pygame.image.load(file_lose_img)
        self.result_rect = self.win.get_rect()
        self.result_rect.center = (WIDTH // 2, HEIGHT // 3)

    def music(self):
        """播放背景音乐"""
        pygame.mixer.init()
        pygame.mixer.music.load(file_bg_snd)
        pygame.mixer.music.set_volume(0.3)
        pygame.mixer.music.play(-1)

    def update_time(self):
        if self.time_left > 0 :
            self.time_left -= 1

    def check_event(self):
        """监听事件：键盘点击事件，游戏退出事件，鼠标点击事件"""
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == MOUSEBUTTONDOWN:
                # 鼠标点击，兔子射箭
                arrow = Arrow(self.arrow_image, self.rabbit.angle, self.rabbit.rotated_position)
                self.arrow_group.add(arrow)
            elif event.type == self.time_left_event:
                self.update_time()

    def create_badger(self):
        """批量生成平头哥"""
        if random.random() > 0.9:
            badger = Badger(self.badger_image, (WIDTH,random.randint(0, HEIGHT)))
            self.badger_group.add(badger)

    def draw_text(self, txt, size, pos, colour):
        myfont = pygame.font.Font("./font/myfont.ttf", size)
        score_text = myfont.render(txt, True, colour)
        text_rect = score_text.get_rect()
        text_rect.center = pos
        self.screen.blit(score_text, text_rect)

    def play(self):
        """游戏的入口"""
        self.music()
        # 设置定时任务
        pygame.time.set_timer(self.time_left_event, 1000)
        running = True  # 是否结束游戏
        is_win = True  # 是否胜利
        while running:
            self.check_event()
            # 将背景图片绑定屏幕上
            self.screen.blit(self.bg, (0,0))
            # 添加4个城堡
            for i in range(4):
                self.screen.blit(self.castle, (0, 30 + i*105))

            # 显示兔子
            self.rabbit.draw(self.screen, pygame.mouse.get_pos())
            # 移动兔子
            key_pressed = pygame.key.get_pressed()
            if key_pressed[K_w]:
                self.rabbit.move('up')
            elif key_pressed[K_s]:
                self.rabbit.move('down')
            elif key_pressed[K_a]:
                self.rabbit.move('left')
            elif key_pressed[K_d]:
                self.rabbit.move('right')

            # 更新弓箭
            for arrow in self.arrow_group:
                if arrow.update():
                    self.arrow_group.remove(arrow)
            self.arrow_group.draw(self.screen)

            # 平头哥
            self.create_badger()
            # self.screen.blit(self.badger.image, self.badger.rect)
            for badger in self.badger_group:
                if badger.update():  # 如果返回True,则攻入城堡，生命值随机减少
                    self.health_value -= random.randint(4,8)

            for badger in self.badger_group:
                badger.draw(self.screen, self.badger_images)

            # 碰撞检测，箭头组和平头哥组的碰撞
            for hit in pygame.sprite.groupcollide(self.arrow_group, self.badger_group, True, True):
                self.score += 1
            # 得分写到屏幕
            self.draw_text("得分:%d" % self.score, 36, (WIDTH // 2, 30), (245, 56, 78))
            # 绘制时间
            self.draw_text("倒计时 :%d" % self.time_left, 36, (WIDTH * 3 // 4, HEIGHT - 30), (25, 22, 25))

            # 城堡生命值
            self.screen.blit(self.healthbar_image, (5,5))
            for i in range(self.health_value):
                self.screen.blit(self.health_image, (i+4, 8))

            if self.health_value <= 0:
                running = False
                is_win = False
            if self.time_left <= 0:
                running = False

            # 刷新屏幕
            pygame.display.update()

        while True:
            self.check_event()
            # 将背景图片绑定屏幕上
            self.screen.blit(self.bg, (0, 0))
            result_image = self.win if is_win else self.lose
            self.screen.blit(result_image, self.result_rect)
            pygame.display.update()


class Rabbit(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load(file_rabbit_img)
        self.rect = self.image.get_rect()
        self.rect.center = (WIDTH//2, HEIGHT//2)
        self.speed = 10

    def draw(self, scr, mouse_pos):
        """先根据鼠标点击位置计算旋转角度"""
        angle = math.atan2(mouse_pos[1] - self.rect.centery, mouse_pos[0] - self.rect.centerx)
        self.angle = angle
        rotate_angle = 360 - angle * DEGREE
        rotated_image = pygame.transform.rotate(self.image, rotate_angle)
        self.rotated_position = (
            self.rect.centerx - rotated_image.get_rect().width / 2,
            self.rect.centery - rotated_image.get_rect().height / 2)
        scr.blit(rotated_image, self.rotated_position)

    def move(self, direction):
        """兔子射手移动"""
        if direction == "right":
            # self.rect.right = self.rect.right + self.speed
            self.rect.right = min(self.rect.right + self.speed, WIDTH)
        elif direction == "left":
            # self.rect.left = self.rect.left - self.speed
            self.rect.left = max(self.rect.left - self.speed, 0)
        elif direction == "up":
            self.rect.top = max(self.rect.top - self.speed, 0)
        elif direction == "down":
            self.rect.bottom = min(self.rect.bottom + self.speed, HEIGHT)


class Arrow(pygame.sprite.Sprite):
    """箭头类"""
    def __init__(self, image, angle, rotated_position):
        pygame.sprite.Sprite.__init__(self)
        self.angle = angle  # 旋转的角度
        # 得到旋转后的图像
        self.image = pygame.transform.rotate(image, 360 - angle * DEGREE)
        self.rect = self.image.get_rect()
        self.rect.left,self.rect.top = rotated_position
        self.speed = 10

    def update(self, *args):
        """更新弓箭"""
        velx = math.cos(self.angle) * self.speed
        vely = math.sin(self.angle) * self.speed
        self.rect.x += velx
        self.rect.y += vely
        # 如果箭头超出边界，让箭头消失
        if self.rect.right < 0 or self.rect.left > WIDTH \
                or self.rect.top > HEIGHT or self.rect.bottom < 0:
            return True
        return False


class Badger(pygame.sprite.Sprite):
    """平头哥类"""
    def __init__(self, image, pos):
        pygame.sprite.Sprite.__init__(self)
        self.image = image
        self.rect = self.image.get_rect()
        self.rect.center = pos
        self.speed = 1
        self.num = 1

    def update(self, *args):
        """移动"""
        self.rect.x -= self.speed
        if self.rect.x <= 0:
            return True  # 攻入城堡
        else:
            return False

    def draw(self, scr, images):
        self.image = images[self.num//5%4]
        self.num += 1
        scr.blit(self.image, self.rect)


if __name__ == '__main__':
    win = MainWindow()
    win.play()
